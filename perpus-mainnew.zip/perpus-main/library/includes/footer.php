<?php
// =========================================
// Footer Template
// =========================================
?>
</div> <!-- /container -->

<footer class="text-center mt-5 mb-3 text-muted">
  <hr>
  <p>&copy; <?php echo date('Y'); ?> Library Management System — Built with PHP & Bootstrap</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
